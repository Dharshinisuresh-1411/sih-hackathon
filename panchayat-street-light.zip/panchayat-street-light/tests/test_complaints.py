def base_payload(pole_number="P-001"):
    return {
        "pole_number": pole_number,
        "caller_name": "Ramesh",
        "caller_phone": "9840011111",
        "description": "Light not working",
    }


def test_unknown_pole_complaint_is_rejected(client):
    res = client.post("/api/complaints", json=base_payload("P-999"))
    assert res.status_code == 404


def test_valid_complaint_created(client, sample_pole):
    res = client.post("/api/complaints", json=base_payload())
    assert res.status_code == 201
    body = res.get_json()
    assert body["duplicate"] is False
    assert body["complaint"]["status"] == "OPEN"


def test_existing_open_complaint_is_detected(client, sample_pole):
    first = client.post("/api/complaints", json=base_payload())
    assert first.status_code == 201

    second = client.post("/api/complaints", json=base_payload())
    assert second.status_code == 200
    body = second.get_json()
    assert body["duplicate"] is True
    assert body["existing_complaint"]["id"] == first.get_json()["complaint"]["id"]


def test_open_complaints_by_ward(client, sample_pole):
    client.post("/api/complaints", json=base_payload())
    res = client.get("/api/reports/open-by-ward")
    assert res.status_code == 200
    wards = {row["ward"]: row["open_complaints"] for row in res.get_json()}
    assert wards.get("Ward 1") == 1
