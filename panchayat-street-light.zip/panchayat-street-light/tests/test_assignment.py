def create_complaint(client):
    res = client.post("/api/complaints", json={
        "pole_number": "P-001", "caller_name": "Ramesh",
        "caller_phone": "9840011111", "description": "Light not working",
    })
    return res.get_json()["complaint"]


def test_complaint_can_be_assigned_to_active_electrician(client, sample_pole, active_electrician):
    complaint = create_complaint(client)
    res = client.post(f"/api/complaints/{complaint['id']}/assign", json={
        "electrician_id": active_electrician.id, "assigned_by": "Clerk",
    })
    assert res.status_code == 200
    assert res.get_json()["status"] == "ASSIGNED"


def test_inactive_electrician_cannot_be_assigned(client, sample_pole, inactive_electrician):
    complaint = create_complaint(client)
    res = client.post(f"/api/complaints/{complaint['id']}/assign", json={
        "electrician_id": inactive_electrician.id, "assigned_by": "Clerk",
    })
    assert res.status_code == 400
    assert "inactive" in res.get_json()["error"].lower()
